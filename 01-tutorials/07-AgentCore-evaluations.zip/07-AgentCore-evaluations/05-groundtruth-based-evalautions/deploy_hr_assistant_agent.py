"""Deploy the HR Assistant agent to AgentCore Runtime using the agentcore CLI.

Run from the notebook via: %run -i deploy_hr_assistant_agent.py

Expects REGION to be set in the caller's namespace (Step 2 config cell).
Sets in the caller's namespace: AGENT_ID, AGENT_ARN, CW_LOG_GROUP, agentcore_client

Uses the agentcore CLI (from bedrock-agentcore-starter-toolkit) which handles
CodeBuild image builds, ECR push, OTel instrumentation, and runtime creation.
"""

import subprocess
import time

import boto3

_REGION = REGION or "us-east-1"  # noqa: F821

# ---- 1. Configure ----
print("Configuring agent ...")
subprocess.run(
    [
        "agentcore",
        "configure",
        "--entrypoint",
        "hr_assistant_agent.py",
        "--name",
        "hr_assistant_eval_tutorial",
        "--region",
        _REGION,
        "--requirements-file",
        "requirements.txt",
        "--non-interactive",
    ],
    check=True,
)
print("Configuration complete.")

# ---- 2. Deploy ----
print("\nDeploying HR Assistant Agent ...")
print("  This takes ~5 minutes on first run (image build + push + runtime creation).")
subprocess.run(
    ["agentcore", "deploy", "--auto-update-on-conflict"],
    check=True,
)
print("Deploy complete.")

# ---- 3. Get status to extract AGENT_ID and AGENT_ARN ----
print("\nRetrieving agent status ...")
result = subprocess.run(
    ["agentcore", "status", "--verbose"],
    capture_output=True,
    text=True,
)
print(result.stdout)

# Parse agent info from the agentcore CLI config
import yaml  # noqa: E402
from pathlib import Path  # noqa: E402

config_path = Path(".bedrock_agentcore.yaml")
if config_path.exists():
    with open(config_path) as f:
        config = yaml.safe_load(f)
    AGENT_ID = config.get("agent_id", "")
    AGENT_ARN = config.get("agent_arn", "")
else:
    # Fallback: query the control plane directly
    cp = boto3.client("bedrock-agentcore-control", region_name=_REGION)
    paginator = cp.get_paginator("list_agent_runtimes")
    AGENT_ID = ""
    AGENT_ARN = ""
    for page in paginator.paginate():
        for rt in page.get("agentRuntimes", []):
            if rt.get("agentRuntimeName") == "hr_assistant_eval_tutorial":
                AGENT_ID = rt["agentRuntimeId"]
                AGENT_ARN = rt["agentRuntimeArn"]
                break
        if AGENT_ID:
            break

# ---- 4. Wait for READY ----
if AGENT_ID:
    cp = boto3.client("bedrock-agentcore-control", region_name=_REGION)
    print("Waiting for READY ...")
    for elapsed in range(0, 600, 15):
        status = cp.get_agent_runtime(agentRuntimeId=AGENT_ID).get("status", "UNKNOWN")
        print(f"  [{elapsed:>3}s] {status}")
        if status in ("READY", "ACTIVE"):
            break
        if status in ("FAILED", "CREATE_FAILED", "UPDATE_FAILED"):
            raise RuntimeError(f"Deploy failed: {status}")
        time.sleep(15)
    else:
        raise TimeoutError("Agent did not reach READY in 600s")

CW_LOG_GROUP = f"/aws/bedrock-agentcore/runtimes/{AGENT_ID}-DEFAULT"
agentcore_client = boto3.client("bedrock-agentcore", region_name=_REGION)

print(f"\nAGENT_ID     : {AGENT_ID}")
print(f"AGENT_ARN    : {AGENT_ARN}")
print(f"CW_LOG_GROUP : {CW_LOG_GROUP}")
print("Deploy complete.")
